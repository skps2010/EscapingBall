package ball;

public enum State {game,menu,select,create,info

}
