package ball;

public class Step {
		String name;
		int step;
		
		public Step(String n,String s)
		{
			name=n;
			step=Integer.parseInt(s);
		}
}
